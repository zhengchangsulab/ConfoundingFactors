library(ggplot2)
library(ggseqlogo)

pwm.set<-Sys.glob("*.pwm")

for(pwm.name in pwm.set){
  pwm.m<-read.table(pwm.name)
  pwm.name.array <- strsplit(pwm.name, ".", fixed=TRUE)
  names(pwm.name.array) <- "one"
  num.id <- pwm.name.array$one[1]
  num.id.str <- as.character(num.id)
  
  diff <- (4-nchar(num.id.str))
  for(i in 1:diff)
  {
    num.id.str <- paste0("0", num.id.str)
  }
  
  pwm.mat<-t(pwm.m)
  rownames(pwm.mat) <- c("A", "C", "G", "T")
  pwm.rename<-sub(pattern="pwm", replacement="pdf", pwm.name)
  pdf(pwm.rename)
  p=ggseqlogo(pwm.mat, method="bits", facet="grid", font = "roboto_medium")  + ggtitle(num.id.str) + theme(plot.title = element_text(size = 20, face = "bold"), axis.text.x = element_text(size = 20, face = "bold"), axis.text.y = element_text(size = 20, face = "bold"), axis.title.x = element_text(size = 20, face = "bold"), axis.title.y = element_text(size = 20, face = "bold"))
  print(p)
  dev.off()
}